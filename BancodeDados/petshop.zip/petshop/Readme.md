# Sistema de Gerenciamento de Dados de PetShop

Este é um sistema de gerenciamento de dados para um PetShop, utilizando um banco de dados relacional PostgreSQL. O sistema permite realizar operações de CRUD (Criação, Leitura, Atualização e Exclusão) em várias tabelas relacionadas a clientes, funcionários, fornecedores, produtos, serviços e atendimentos. Além disso, o sistema executa consultas agregadas e gera visualizações gráficas baseadas nos resultados.

drop = {
    "TipoFuncionario" : ("DROP TABLE IF EXISTS TipoFuncionario CASCADE"),
    "Funcionario" : ("DROP TABLE IF EXISTS Funcionario CASCADE"),
    "Fornecedor" : ("DROP TABLE IF EXISTS Fornecedor CASCADE"),
    "TipoServico" : ("DROP TABLE IF EXISTS TipoServico CASCADE"),
    "TipoProduto" : ("DROP TABLE IF EXISTS TipoProduto CASCADE"),
    "Especie" : ("DROP TABLE IF EXISTS Especie CASCADE"),
    "Cliente" : ("DROP TABLE IF EXISTS Cliente CASCADE"),
    "Raca" : ("DROP TABLE IF EXISTS Raca CASCADE"),
    "Animal" : ("DROP TABLE IF EXISTS Animal CASCADE"),
    "Produto" : ("DROP TABLE IF EXISTS Produto CASCADE"),
    "NotaCompra" : ("DROP TABLE IF EXISTS NotaCompra CASCADE"),
    "Servico" : ("DROP TABLE IF EXISTS Servico CASCADE"),
    "NotaCompraProduto" : ("DROP TABLE IF EXISTS NotaCompraProduto CASCADE"),
    "NotaVenda" : ("DROP TABLE IF EXISTS NotaVenda CASCADE"),
    "Atendimento" : ("DROP TABLE IF EXISTS Atendimento CASCADE"),
    "AtendimentoProduto" : ("DROP TABLE IF EXISTS AtendimentoProduto CASCADE")
}

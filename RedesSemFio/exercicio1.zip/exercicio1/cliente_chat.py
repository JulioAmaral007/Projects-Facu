import socket
import threading

# Função para enviar mensagens para o servidor
def send_message(client_socket):
    while True:
        message = input('Digite sua mensagem: ')
        client_socket.send(message.encode('utf-8'))

# Função para receber mensagens do servidor
def receive_message(client_socket):
    while True:
        try:
            message = client_socket.recv(1024).decode('utf-8')
            print(message)
        except:
            print("Erro ao receber a mensagem. Conexão fechada.")
            client_socket.close()
            break

# Configuração do cliente
def start_client():
    client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    client_socket.connect(('127.0.0.1', 5555))  # Conecta ao servidor local (127.0.0.1)

    # Inicia duas threads: uma para enviar e outra para receber mensagens
    send_thread = threading.Thread(target=send_message, args=(client_socket,))
    receive_thread = threading.Thread(target=receive_message, args=(client_socket,))

    send_thread.start()
    receive_thread.start()

# Inicia o cliente
start_client()

import socket
import threading

# Função para lidar com mensagens de um cliente
def handle_client(client_socket, client_address):
    print(f"[NOVO CLIENTE] {client_address} conectado.")
    
    while True:
        try:
            # Recebe mensagem do cliente
            message = client_socket.recv(1024).decode('utf-8')
            if message:
                print(f"[MENSAGEM] {client_address}: {message}")
                broadcast(message, client_socket)  # Repassa a mensagem para os outros clientes
        except:
            # Se houver erro ou desconexão, fecha o socket do cliente e remove-o da lista
            print(f"[DESCONECTADO] {client_address} desconectado.")
            client_socket.close()
            clients.remove(client_socket)
            break

# Função para repassar as mensagens a todos os outros clientes conectados
def broadcast(message, client_socket):
    for client in clients:
        if client != client_socket:
            try:
                client.send(message.encode('utf-8'))  # Envia a mensagem codificada
            except:
                # Caso o envio falhe, remove o cliente
                client.close()
                clients.remove(client)

# Configuração do servidor
def start_server():
    server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server.bind(('0.0.0.0', 5555))  # IP genérico para escutar todas as interfaces de rede
    server.listen()

    print("[SERVIDOR] Servidor de chat iniciado. Aguardando conexões...")

    while True:
        client_socket, client_address = server.accept()  # Aceita nova conexão
        clients.append(client_socket)  # Adiciona cliente à lista de clientes conectados
        # Inicia uma nova thread para lidar com o cliente
        client_thread = threading.Thread(target=handle_client, args=(client_socket, client_address))
        client_thread.start()

# Lista para armazenar os sockets dos clientes conectados
clients = []

# Inicia o servidor
start_server()
